
"use strict";

const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const multer = require("multer");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET";
const COOKIE_NAME = "jkt48_session";

if (process.env.NODE_ENV === "production" && JWT_SECRET === "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET") {
  throw new Error("JWT_SECRET wajib diganti saat production.");
}

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "uploads", "events");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, "jkt48.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  buyer_code TEXT UNIQUE,
  username TEXT UNIQUE,
  email TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  whatsapp TEXT,
  role TEXT NOT NULL CHECK(role IN ('owner','admin','buyer')),
  balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  event_date TEXT NOT NULL,
  event_time TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price >= 0),
  stock INTEGER NOT NULL CHECK(stock >= 0),
  sold INTEGER NOT NULL DEFAULT 0 CHECK(sold >= 0),
  link TEXT NOT NULL,
  image_path TEXT,
  posted_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(posted_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  transaction_code TEXT UNIQUE NOT NULL,
  buyer_id INTEGER NOT NULL,
  event_id INTEGER NOT NULL,
  price INTEGER NOT NULL,
  balance_before INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'Berhasil',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(buyer_id) REFERENCES users(id),
  FOREIGN KEY(event_id) REFERENCES events(id)
);

CREATE TABLE IF NOT EXISTS balance_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  buyer_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  balance_before INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  type TEXT NOT NULL,
  actor_id INTEGER,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(buyer_id) REFERENCES users(id),
  FOREIGN KEY(actor_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);

const ownerExists = db.prepare("SELECT id FROM users WHERE role='owner' LIMIT 1").get();
if (!ownerExists) {
  const hash = bcrypt.hashSync(process.env.OWNER_PASSWORD || "mich", 12);
  db.prepare(`
    INSERT INTO users (username,email,password_hash,name,role)
    VALUES (?,NULL,?,?, 'owner')
  `).run("michie", hash, "Owner");
}

db.prepare(`
  INSERT OR IGNORE INTO settings(key,value) VALUES('maintenance','0')
`).run();

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${Date.now()}-${crypto.randomBytes(8).toString("hex")}${ext}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    cb(null, allowed.includes(file.mimetype));
  }
});

app.disable("x-powered-by");
app.use(helmet({
  crossOriginResourcePolicy: { policy: "same-origin" },
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "blob:"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Terlalu banyak percobaan. Coba lagi nanti." }
});

app.use("/api/auth", authLimiter);
app.use("/uploads", express.static(path.join(ROOT, "uploads"), {
  maxAge: "1d",
  dotfiles: "deny"
}));

function jsonError(res, status, message) {
  return res.status(status).json({ error: message });
}

function getMaintenance() {
  return db.prepare("SELECT value FROM settings WHERE key='maintenance'").get()?.value === "1";
}

function cleanUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    buyerId: row.buyer_code,
    username: row.username,
    email: row.email,
    name: row.name,
    whatsapp: row.whatsapp,
    role: row.role,
    balance: row.balance,
    active: Boolean(row.active),
    createdAt: row.created_at
  };
}

function issueSession(user) {
  return jwt.sign(
    { sub: user.id, role: user.role },
    JWT_SECRET,
    { expiresIn: "8h" }
  );
}

function setSession(res, user) {
  res.cookie(COOKIE_NAME, issueSession(user), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    maxAge: 8 * 60 * 60 * 1000,
    path: "/"
  });
}

function requireAuth(req, res, next) {
  const token = req.cookies[COOKIE_NAME];
  if (!token) return jsonError(res, 401, "Belum login.");

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare("SELECT * FROM users WHERE id=? AND active=1").get(payload.sub);
    if (!user) return jsonError(res, 401, "Sesi tidak valid.");
    req.user = cleanUser(user);
    next();
  } catch {
    return jsonError(res, 401, "Sesi kedaluwarsa. Silakan login lagi.");
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return jsonError(res, 403, "Akses ditolak.");
    }
    next();
  };
}

function blockMaintenance(req, res, next) {
  if (getMaintenance() && req.user.role !== "owner") {
    return jsonError(res, 503, "Mode maintenance aktif.");
  }
  next();
}

function normalizeUrl(value) {
  try {
    const u = new URL(String(value));
    if (!["http:", "https:"].includes(u.protocol)) throw new Error();
    return u.href;
  } catch {
    return null;
  }
}

function uniqueBuyerCode() {
  for (let i = 0; i < 100; i++) {
    const code = String(1000 + crypto.randomInt(0, 9000));
    if (!db.prepare("SELECT id FROM users WHERE buyer_code=?").get(code)) return code;
  }
  throw new Error("Tidak dapat membuat ID pembeli unik.");
}

function eventDTO(row) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    date: row.event_date,
    time: row.event_time,
    price: row.price,
    stock: row.stock,
    sold: row.sold,
    link: row.link,
    image: row.image_path,
    postedBy: row.posted_by_name,
    postedByUsername: row.posted_by_username,
    createdAt: row.created_at
  };
}

function transactionDTO(row) {
  return {
    id: row.transaction_code,
    buyerId: row.buyer_code,
    buyerName: row.buyer_name,
    buyerEmail: row.buyer_email,
    eventId: row.event_id,
    eventName: row.event_name,
    eventDate: row.event_date,
    eventTime: row.event_time,
    eventLink: row.event_link,
    price: row.price,
    saldoSebelum: row.balance_before,
    saldoSesudah: row.balance_after,
    status: row.status,
    createdAt: row.created_at
  };
}

const eventSelect = `
SELECT e.*, u.name AS posted_by_name, u.username AS posted_by_username
FROM events e
JOIN users u ON u.id=e.posted_by
`;

const transactionSelect = `
SELECT
  t.*,
  b.buyer_code,
  b.name AS buyer_name,
  b.email AS buyer_email,
  e.name AS event_name,
  e.event_date,
  e.event_time,
  e.link AS event_link
FROM transactions t
JOIN users b ON b.id=t.buyer_id
JOIN events e ON e.id=t.event_id
`;

app.post("/api/auth/register", (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const whatsapp = String(req.body.whatsapp || "").trim();

  if (!name || !email || !password || !whatsapp) return jsonError(res, 400, "Semua data wajib diisi.");
  if (name.length > 100) return jsonError(res, 400, "Nama terlalu panjang.");
  if (password.length < 6) return jsonError(res, 400, "Password minimal 6 karakter.");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return jsonError(res, 400, "Email tidak valid.");

  const exists = db.prepare("SELECT id FROM users WHERE email=?").get(email);
  if (exists) return jsonError(res, 409, "Email sudah digunakan.");

  const buyerCode = uniqueBuyerCode();
  const passwordHash = bcrypt.hashSync(password, 12);

  const result = db.prepare(`
    INSERT INTO users (buyer_code,email,password_hash,name,whatsapp,role)
    VALUES (?,?,?,?,?,'buyer')
  `).run(buyerCode, email, passwordHash, name, whatsapp);

  const user = db.prepare("SELECT * FROM users WHERE id=?").get(result.lastInsertRowid);

  res.status(201).json({
    message: "Akun berhasil dibuat.",
    user: cleanUser(user)
  });
});

app.post("/api/auth/login", (req, res) => {
  const identifier = String(req.body.identifier || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  const user = db.prepare(`
    SELECT * FROM users
    WHERE active=1 AND (lower(email)=? OR lower(username)=?)
    LIMIT 1
  `).get(identifier, identifier);

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return jsonError(res, 401, "Username/email atau password salah.");
  }

  setSession(res, user);

  res.json({
    message: "Login berhasil.",
    user: cleanUser(user),
    maintenance: getMaintenance()
  });
});

app.post("/api/auth/logout", (_req, res) => {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/"
  });
  res.json({ message: "Logout berhasil." });
});

app.get("/api/auth/me", requireAuth, (req, res) => {
  const fresh = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  res.json({ user: cleanUser(fresh), maintenance: getMaintenance() });
});

app.get("/api/settings/maintenance", requireAuth, (req, res) => {
  res.json({ maintenance: getMaintenance() });
});

app.get("/api/events", requireAuth, (req, res) => {
  const rows = db.prepare(`${eventSelect} ORDER BY e.created_at DESC`).all();
  res.json({ events: rows.map(eventDTO) });
});

app.post(
  "/api/events",
  requireAuth,
  requireRole("owner", "admin"),
  blockMaintenance,
  upload.single("image"),
  (req, res) => {
    const name = String(req.body.name || "").trim();
    const description = String(req.body.description || "").trim();
    const date = String(req.body.date || "").trim();
    const time = String(req.body.time || "").trim();
    const price = Number(req.body.price);
    const stock = Number(req.body.stock);
    const link = normalizeUrl(req.body.link);

    if (!name || !description || !date || !time || !Number.isInteger(price) || price < 0 ||
        !Number.isInteger(stock) || stock < 1 || !link || !req.file) {
      if (req.file) fs.rmSync(req.file.path, { force: true });
      return jsonError(res, 400, "Data event tidak lengkap atau tidak valid.");
    }

    const imagePath = `/uploads/events/${req.file.filename}`;

    try {
      const result = db.prepare(`
        INSERT INTO events
          (name,description,event_date,event_time,price,stock,link,image_path,posted_by)
        VALUES (?,?,?,?,?,?,?,?,?)
      `).run(name, description, date, time, price, stock, link, imagePath, req.user.id);

      const row = db.prepare(`${eventSelect} WHERE e.id=?`).get(result.lastInsertRowid);
      res.status(201).json({ message: "Event berhasil diposting.", event: eventDTO(row) });
    } catch (err) {
      fs.rmSync(req.file.path, { force: true });
      console.error(err);
      return jsonError(res, 500, "Gagal menyimpan event.");
    }
  }
);

app.delete(
  "/api/events/:id",
  requireAuth,
  requireRole("owner"),
  blockMaintenance,
  (req, res) => {
    const event = db.prepare("SELECT * FROM events WHERE id=?").get(Number(req.params.id));
    if (!event) return jsonError(res, 404, "Event tidak ditemukan.");

    const used = db.prepare("SELECT id FROM transactions WHERE event_id=? LIMIT 1").get(event.id);
    if (used) return jsonError(res, 409, "Event yang sudah memiliki transaksi tidak dapat dihapus.");

    db.prepare("DELETE FROM events WHERE id=?").run(event.id);

    if (event.image_path) {
      const filename = path.basename(event.image_path);
      fs.rmSync(path.join(UPLOAD_DIR, filename), { force: true });
    }

    res.json({ message: "Event berhasil dihapus." });
  }
);

app.post(
  "/api/transactions",
  requireAuth,
  requireRole("buyer"),
  blockMaintenance,
  (req, res) => {
    const eventId = Number(req.body.eventId);
    if (!Number.isInteger(eventId)) return jsonError(res, 400, "Event tidak valid.");

    const purchase = db.transaction(() => {
      const buyer = db.prepare("SELECT * FROM users WHERE id=? AND role='buyer' AND active=1").get(req.user.id);
      const event = db.prepare("SELECT * FROM events WHERE id=?").get(eventId);

      if (!buyer) throw new Error("Pembeli tidak ditemukan.");
      if (!event) throw new Error("Event tidak ditemukan.");
      if (event.stock <= 0) throw new Error("Stok event habis.");
      if (buyer.balance < event.price) throw new Error("Saldo tidak cukup.");

      const before = buyer.balance;
      const after = before - event.price;
      const code = "TRX-" + Date.now().toString(36).toUpperCase() + "-" + crypto.randomBytes(3).toString("hex").toUpperCase();

      db.prepare("UPDATE users SET balance=? WHERE id=?").run(after, buyer.id);
      db.prepare("UPDATE events SET stock=stock-1,sold=sold+1 WHERE id=? AND stock>0").run(event.id);

      db.prepare(`
        INSERT INTO transactions
          (transaction_code,buyer_id,event_id,price,balance_before,balance_after,status)
        VALUES (?,?,?,?,?,?,'Berhasil')
      `).run(code, buyer.id, event.id, event.price, before, after);

      const row = db.prepare(`${transactionSelect} WHERE t.transaction_code=?`).get(code);
      return transactionDTO(row);
    });

    res.status(201).json({ message: "Pembelian berhasil.", transaction: purchase });
  }
);

app.get("/api/transactions/my", requireAuth, requireRole("buyer"), (req, res) => {
  const rows = db.prepare(`${transactionSelect} WHERE t.buyer_id=? ORDER BY t.created_at DESC`).all(req.user.id);
  res.json({ transactions: rows.map(transactionDTO) });
});

app.get("/api/transactions", requireAuth, requireRole("owner"), (req, res) => {
  const rows = db.prepare(`${transactionSelect} ORDER BY t.created_at DESC`).all();
  res.json({ transactions: rows.map(transactionDTO) });
});

app.get("/api/buyers", requireAuth, requireRole("owner"), (req, res) => {
  const rows = db.prepare(`
    SELECT
      u.*,
      COUNT(t.id) AS transaction_count
    FROM users u
    LEFT JOIN transactions t ON t.buyer_id=u.id
    WHERE u.role='buyer'
    GROUP BY u.id
    ORDER BY u.created_at DESC
  `).all();

  res.json({
    buyers: rows.map(row => ({
      ...cleanUser(row),
      transactionCount: row.transaction_count
    }))
  });
});

app.get("/api/buyers/:buyerCode", requireAuth, requireRole("owner"), (req, res) => {
  const row = db.prepare(`
    SELECT * FROM users WHERE buyer_code=? AND role='buyer'
  `).get(req.params.buyerCode);

  if (!row) return jsonError(res, 404, "Pembeli tidak ditemukan.");
  res.json({ buyer: cleanUser(row) });
});

app.post(
  "/api/buyers/:buyerCode/topup",
  requireAuth,
  requireRole("owner", "admin"),
  blockMaintenance,
  (req, res) => {
    const amount = Number(req.body.amount);
    if (!Number.isInteger(amount) || amount <= 0) {
      return jsonError(res, 400, "Jumlah saldo harus lebih dari Rp0.");
    }

    const result = db.transaction(() => {
      const buyer = db.prepare(`
        SELECT * FROM users WHERE buyer_code=? AND role='buyer' AND active=1
      `).get(req.params.buyerCode);

      if (!buyer) throw new Error("Pembeli tidak ditemukan.");

      const before = buyer.balance;
      const after = before + amount;

      db.prepare("UPDATE users SET balance=? WHERE id=?").run(after, buyer.id);
      db.prepare(`
        INSERT INTO balance_logs
          (buyer_id,amount,balance_before,balance_after,type,actor_id,note)
        VALUES (?,? ,?,?, 'topup',?,?)
      `).run(
        buyer.id,
        amount,
        before,
        after,
        req.user.id,
        `Top up oleh ${req.user.role}: ${req.user.name}`
      );

      return { before, after, buyer: cleanUser(db.prepare("SELECT * FROM users WHERE id=?").get(buyer.id)) };
    });

    res.json({
      message: "Saldo berhasil ditambahkan.",
      ...result
    });
  }
);

app.get("/api/admins", requireAuth, requireRole("owner"), (req, res) => {
  const rows = db.prepare(`
    SELECT id,username,name,active,created_at
    FROM users
    WHERE role='admin'
    ORDER BY created_at DESC
  `).all();

  res.json({
    admins: rows.map(a => ({
      id: a.id,
      username: a.username,
      name: a.name,
      active: Boolean(a.active),
      createdAt: a.created_at
    }))
  });
});

app.post(
  "/api/admins",
  requireAuth,
  requireRole("owner"),
  (req, res) => {
    const name = String(req.body.name || "").trim();
    const username = String(req.body.username || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (!name || !username || password.length < 6) {
      return jsonError(res, 400, "Nama, username, dan password minimal 6 karakter wajib diisi.");
    }

    if (!/^[a-z0-9._-]{3,30}$/.test(username)) {
      return jsonError(res, 400, "Username hanya boleh berisi huruf kecil, angka, titik, garis bawah, atau strip.");
    }

    if (username === "michie") return jsonError(res, 409, "Username Owner tidak dapat digunakan.");

    const exists = db.prepare("SELECT id FROM users WHERE username=?").get(username);
    if (exists) return jsonError(res, 409, "Username sudah digunakan.");

    const hash = bcrypt.hashSync(password, 12);
    const result = db.prepare(`
      INSERT INTO users(username,password_hash,name,role)
      VALUES(?,?,?,'admin')
    `).run(username, hash, name);

    res.status(201).json({
      message: "Admin berhasil dibuat.",
      admin: {
        id: result.lastInsertRowid,
        username,
        name,
        active: true
      }
    });
  }
);

app.delete("/api/admins/:id", requireAuth, requireRole("owner"), (req, res) => {
  const id = Number(req.params.id);
  const admin = db.prepare("SELECT id,username FROM users WHERE id=? AND role='admin'").get(id);
  if (!admin) return jsonError(res, 404, "Admin tidak ditemukan.");

  db.prepare("UPDATE users SET active=0 WHERE id=?").run(id);
  res.json({ message: "Admin berhasil dinonaktifkan." });
});

app.put(
  "/api/settings/maintenance",
  requireAuth,
  requireRole("owner"),
  (req, res) => {
    const enabled = Boolean(req.body.enabled);
    db.prepare("UPDATE settings SET value=? WHERE key='maintenance'").run(enabled ? "1" : "0");
    res.json({ message: enabled ? "Maintenance aktif." : "Maintenance dimatikan.", maintenance: enabled });
  }
);

app.get("/api/dashboard", requireAuth, requireRole("owner"), (req, res) => {
  const buyers = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='buyer'").get().n;
  const events = db.prepare("SELECT COUNT(*) AS n FROM events").get().n;
  const transactions = db.prepare("SELECT COUNT(*) AS n FROM transactions").get().n;
  const sales = db.prepare("SELECT COALESCE(SUM(price),0) AS n FROM transactions WHERE status='Berhasil'").get().n;
  const buyerBalance = db.prepare("SELECT COALESCE(SUM(balance),0) AS n FROM users WHERE role='buyer'").get().n;

  res.json({
    buyers,
    events,
    transactions,
    sales,
    buyerBalance,
    maintenance: getMaintenance()
  });
});

app.use("/api", (_req, res) => jsonError(res, 404, "API tidak ditemukan."));

app.use(express.static(path.join(ROOT, "public"), {
  extensions: ["html"],
  index: "index.html"
}));

app.get("*splat", (_req, res) => {
  res.sendFile(path.join(ROOT, "public", "index.html"));
});

app.use((err, _req, res, _next) => {
  console.error(err);
  if (err instanceof multer.MulterError) {
    return jsonError(res, 400, err.code === "LIMIT_FILE_SIZE"
      ? "Ukuran gambar maksimal 5 MB."
      : "Upload gambar gagal.");
  }
  return jsonError(res, 500, "Terjadi kesalahan server.");
});

app.listen(PORT, () => {
  console.log(`JKT48 Live Event Store berjalan di http://localhost:${PORT}`);
  console.log("Owner default: michie");
  console.log("Ganti OWNER_PASSWORD dan JWT_SECRET sebelum production.");
});
