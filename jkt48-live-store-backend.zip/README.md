# JKT48 Live Event Store — Backend + SQLite

## 1. Persyaratan

- Node.js 20 atau lebih baru
- npm

## 2. Install

```bash
npm install
```

## 3. Jalankan

```bash
npm start
```

Buka:

```text
http://localhost:3000
```

## 4. Login Owner default

Username:

```text
michie
```

Password default:

```text
mich
```

Untuk production, ubah password Owner dengan environment variable `OWNER_PASSWORD` saat database pertama kali dibuat.

Contoh Linux/macOS:

```bash
OWNER_PASSWORD="password-kuat" JWT_SECRET="rahasia-random-yang-panjang" npm start
```

Windows PowerShell:

```powershell
$env:OWNER_PASSWORD="password-kuat"
$env:JWT_SECRET="rahasia-random-yang-panjang"
npm start
```

> Jika database sudah pernah dibuat, `OWNER_PASSWORD` tidak otomatis mengubah password Owner yang sudah ada. Untuk instalasi baru gunakan environment variable tersebut sebelum server pertama kali dijalankan.

## 5. Struktur

```text
jkt48-live-store/
├── package.json
├── server.js
├── public/
│   └── index.html
├── data/
│   └── jkt48.sqlite       # dibuat otomatis
└── uploads/
    └── events/             # dibuat otomatis
```

## 6. Fitur backend

- Register buyer
- ID buyer random 4 digit
- Password hash bcrypt
- Login server-side menggunakan JWT httpOnly cookie
- Logout menghapus cookie session
- Owner/Admin/Buyer role
- SQLite
- Posting event + upload gambar
- Link event wajib
- Pembelian diproses dalam transaction SQLite
- Saldo dan stok diubah server-side
- Riwayat transaksi
- Top up oleh Owner/Admin
- Kelola Admin
- Kelola Pembeli
- Dashboard Owner
- Maintenance mode
- Rate limit login
- Helmet security headers

## Catatan keamanan

Versi ini sudah jauh lebih aman daripada menyimpan saldo/password di localStorage, tetapi sebelum menerima uang sungguhan tetap lakukan hardening production: gunakan HTTPS, secret environment yang kuat, backup database, monitoring, validasi tambahan, dan payment gateway resmi.
